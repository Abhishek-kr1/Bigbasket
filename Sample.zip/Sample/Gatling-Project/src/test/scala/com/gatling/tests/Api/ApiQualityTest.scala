import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class BigBasketSimulation extends Simulation {

  val httpProtocol = http
    .baseUrl("https://www.bigbasket.com") // set the base URL
    .inferHtmlResources() // enable automatic inference of resources like CSS and JS files
    .acceptHeader("text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
    .acceptEncodingHeader("gzip, deflate, br")
    .acceptLanguageHeader("en-US,en;q=0.5")
    .userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3")

  val headers = Map(
    "Content-Type" -> "application/x-www-form-urlencoded",
    "Origin" -> "https://www.bigbasket.com",
    "Referer" -> "https://www.bigbasket.com/",
    "Sec-Fetch-Dest" -> "document",
    "Sec-Fetch-Mode" -> "navigate",
    "Sec-Fetch-Site" -> "same-origin",
    "Sec-GPC" -> "1",
    "Upgrade-Insecure-Requests" -> "1")

  val scn = scenario("BigBasket Scenario")
    .exec(http("Home Page")
      .get("/")
      .check(status.is(200)))
    .pause(2.seconds)
    .exec(http("Login")
      .post("/auth/login")
      .headers(headers)
      .formParam("loginId", "myusername")
      .formParam("password", "mypassword")
      .check(status.is(200))) // assert that the response code is 200
    .pause(2.seconds)
    .exec(http("Search for Apples")
      .get("/cl/fruits-vegetables/fruits/fresh-fruits/apples/?nc=nb")
      .check(status.is(200))) // assert that the response code is 200
    .pause(2.seconds)
    .repeat(10) {
      exec(http("Add Item to Basket")
        .post("/basket/add")
        .formParam("basketId", "0")
        .formParam("qty", "1")
        .formParam("bsId", "0")
        .formParam("action", "ADD")
        .formParam("variant", "Apple-Kashmiri 1 Kg")
        .check(status.is(200))) // assert that the response code is 200
        .pause(1.second)
    }

  setUp(
    scn.inject(
      rampUsers(10) during (10.seconds)
    )
  ).protocols(httpProtocol)
}